-- VentaComida: almacenamiento de galería y persistencia del perfil
-- La migración equivalente ya fue aplicada en Supabase (2026-10-10).
-- Ejecutar solo si se instala en un proyecto nuevo.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('business-gallery','business-gallery',true,52428800,
array['image/jpeg','image/png','image/webp','video/mp4','video/webm'])
on conflict(id) do update set public=true,file_size_limit=52428800,allowed_mime_types=excluded.allowed_mime_types;
do $$ begin
 if not exists(select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='business_gallery_public_read') then
  create policy business_gallery_public_read on storage.objects for select to public using(bucket_id='business-gallery');
 end if;
 if not exists(select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='business_gallery_staff_insert') then
  create policy business_gallery_staff_insert on storage.objects for insert to authenticated with check(bucket_id='business-gallery' and public.catalog_has_module('business'));
 end if;
 if not exists(select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='business_gallery_staff_delete') then
  create policy business_gallery_staff_delete on storage.objects for delete to authenticated using(bucket_id='business-gallery' and public.catalog_has_module('business'));
 end if;
 if not exists(select 1 from pg_policies where schemaname='storage' and tablename='objects' and policyname='business_gallery_staff_update') then
  create policy business_gallery_staff_update on storage.objects for update to authenticated using(bucket_id='business-gallery' and public.catalog_has_module('business')) with check(bucket_id='business-gallery' and public.catalog_has_module('business'));
 end if;
end $$;
create or replace function public.catalog_config_save(p_module text,p_data jsonb)
returns jsonb language plpgsql security definer set search_path to ''
as $function$
declare current_data jsonb; keys text[]; key text; patch jsonb:='{}';
begin
 if auth.uid() is null or not public.catalog_has_module(p_module) then raise exception 'No tienes acceso a este módulo.'; end if;
 keys:=case p_module when 'business' then array['businessName','tagline','logo','whatsapp','deliveryEnabled','origin','map','payments','socials','publicProfile','businessHours','businessAddress','businessPin'] when 'design' then array['design'] when 'trip' then array['shipping'] else null end;
 if keys is null or jsonb_typeof(p_data)<>'object' or length(p_data::text)>5000000 then raise exception 'Configuración inválida.'; end if;
 foreach key in array keys loop if p_data?key then patch:=patch||jsonb_build_object(key,p_data->key); end if; end loop;
 if p_module='trip' and exists(select 1 from jsonb_each_text(coalesce(p_data->'shipping','{}')) j where j.key in('base','perKm','margin','rounding','freeFrom') and (j.value::numeric<0 or j.value::numeric>1000000)) then raise exception 'Las tarifas deben ser números positivos o cero.'; end if;
 if p_module='business' and p_data?'payments' and (jsonb_typeof(p_data->'payments')<>'array' or jsonb_array_length(p_data->'payments')>20) then raise exception 'Máximo 20 métodos de pago.'; end if;
 if p_module='business' and p_data?'publicProfile' then
  if jsonb_typeof(p_data->'publicProfile')<>'object' then raise exception 'Perfil inválido.'; end if;
  if (p_data->'publicProfile')?'gallery' and (jsonb_typeof(p_data->'publicProfile'->'gallery')<>'array' or jsonb_array_length(p_data->'publicProfile'->'gallery')>40) then raise exception 'Galería inválida.'; end if;
 end if;
 insert into public.catalog_settings(id,data) values(1,patch) on conflict(id) do update set data=public.catalog_settings.data||patch,updated_at=now() returning data into current_data;
 return current_data;
end $function$;
